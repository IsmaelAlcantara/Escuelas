/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package escuelas;

import com.sun.javafx.geom.transform.CanTransformVec3d;
import javax.swing.JOptionPane;

/**
 *
 * @author DELL
 */
public class Escuelas {
    private String [] escuelas={"TESJI","UMB","Normal","UPN","Continental"};
    
    public int [] cantidades = new int[escuelas.length];
    
    
    
    public String [] escuelasRecibir={"TESJI","UMB","Normal","UPN","Continental"};
    public String accederEscuelas(int i){
    return accederEscuelas(i);

    }
    public void pedirDatos(){
        int i, j, aux;
        for (i = 0; i < cantidades.length; i++) {
            
            cantidades[i]= Integer.parseInt(JOptionPane.showInputDialog("ingrese el la cantidad de los juguetes para " + escuelas[i]));
        
       
         System.out.println(cantidades[i]+ " " +escuelas[i]);
        }
    }
    
    public void ordenar(){
       /* int i, j, aux;
        
            for (i=0; i<cantidades.length -1; i++){
              for (j=0; j<cantidades.length-i-1; j++){
                  if (cantidades[j+1]<cantidades[j]){
                      aux=cantidades[j+1];
                      cantidades[j+1]=cantidades[j];
                      cantidades[j]=aux;
                  }
              }
              
             }
        
        System.out.println("Empieza orden");
        
            System.out.println(cantidades[i]);
        */
       for(int i = 0; i < cantidades.length - 1 ; i++)
        {
            for(int j = 0; j < cantidades.length - 1; j++)
            {
                if (cantidades[j] < cantidades[j + 1])
                {
                    int tmp = cantidades[j+1];
                    cantidades[j+1] = cantidades[j];
                    cantidades[j] = tmp;
                }
            }
        }
       System.out.print("Empieza orden"+ "\n");
        for(int i = 0;i < 3; i++)
        {
           
            
            System.out.print(cantidades[i]+"\n");
        }
    
            
        
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Escuelas obj=new Escuelas();
        obj.pedirDatos();
        obj.ordenar();
    }
    
}
